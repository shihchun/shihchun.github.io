% 期末考實作
% 黃仕鈞
% Wen,4 Jan 2017

## 操作

<kbd>Esc</kbd>、<kbd>↑</kbd>、<kbd>↓</kbd>、<kbd>←</kbd>、<kbd>→</kbd>

##

![題目](image/題目.jpg)



## 切網段

![切網段](image/切網段.png)

| 順序   | 1       | 2       | 3       | 4       |
|--------|---------|---------|---------|---------|
| int    | vlan2   | vlan3   | vlan4   | R1      |
| 切台數 | 64      | 32      | 16      | 8       |
| 網段頭 | 80.0    | 80.64   | 80.96  | 80.112  |
| 網段尾 | 80.63   | 80.95   | 80.111  | 80.119  |
| 遮罩   | 255.192 | 255.224 | 255.240 | 255.248 |

## Switch Trunk

![Trunk設定](image/Trunk.jpg)

##
```bash
Switch>en
Switch#confi
Configuring from terminal, memory, or network [terminal]?
```
```bash
Switch0(config)#int fa0/2
Switch0(config-if)#switchport mode trunk
Switch0(config-if)#int fa0/3
Switch0(config-if)#switchport mode trunk
```
```bash
Switch1(config)#int fa0/2
Switch1(config-if)#switchport mode trunk
```
## 設定Vlan、vlan name
![vlan](image/vlan.png)

##
```bash
Switch>en
Switch#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Switch(config)#vlan 2
Switch(config-vlan)#name v2
Switch(config-vlan)#vlan 3
Switch(config-vlan)#name v3
Switch(config-vlan)#vlan 4
Switch(config-vlan)#name v4
```
```bash
Switch(config-vlan)#int fa0/4
Switch(config-if)#switchport access vlan2
Switch(config-if)#switchport access vlan 2
Switch(config-if)#int fa0/5
Switch(config-if)#switchport access vlan 4
Switch(config-if)#int fa0/6
Switch(config-if)#switchport access vlan 3
```
## 設定 IP
![](image/IP設定.png)

## 子網段設定
```bash
Router#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router1(config)#int fa0/0
Router1(config-if)#no shutdown
Router1(config-if)#int fa0/0.1
Router1(config-subif)#ip address  192.168.80.1 255.255.255.192
Router1(config-subif)#int fa0/0.2
Router1(config-subif)#ip address 192.168.80.65 255.255.255.224
Router1(config-subif)#int fa0/0.3
Router1(config-subif)#ip address 192.168.80.97 255.255.255.240
```

## EIGRP 設定
```bash
Router1>en
Router1#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router1(config)#router eigrp 100
Router1(config-router)#network 192.168.80.253
%DUAL-5-NBRCHANGE: IP-EIGRP 100: Neighbor 192.168.80.254 (Serial1/0) is up: new adjacency
Router1(config-router)#network 192.168.80.113
```

```bash
Router2(config)#router eigrp 100
Router2(config-router)#network 192.168.80.254
Router2(config-router)#network 192.168.80.249
Router2(config-router)#network 192.168.80.0
Router2(config-router)#network 192.168.80.64
Router2(config-router)#network 192.168.80.96
```

##

```bash
Router3(config)#router eigrp 100
Router3(config-router)#network 192.168.80.250
%DUAL-5-NBRCHANGE: IP-EIGRP 100: Neighbor 192.168.80.249 (Serial1/0) is up: new adjacency
Router3(config-router)#network 192.168.10.1
%DUAL-5-NBRCHANGE: IP-EIGRP 100: Neighbor 192.168.10.2 (Serial1/1) is up: new adjacency
Router3(config-router)#network 192.168.20.1
Router3(config-router)#network 192.168.30.1
Router3(config-router)#no auto-summary
```
```bash
Router4(config)#router eigrp 100
Router4(config-router)#network 192.168.10.2
Router4(config-router)#network 192.168.40.1
Router4(config-router)#network 192.168.50.1
Router4(config-router)#no auto-summary
```
##
![已經完成2、3](image/題目.jpg)

## 30.2不能ping 50.2

```bash
Router3>en
Router3#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router3(config)#access-list 10 deny host 192.168.50.2
Router3(config)#access-list 10 permit any
Router3(config)#int fa0/1
Router3(config-if)#ip access-group 10 out
```
##
![OUT and IN](image/OUT:IN.jpg)

## 設定密碼

- 自己的密碼
```bash
Router>en
Router#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router(config)#enable secret cisco
```

- 遠端登入的密碼
```bash
Router>en
Password:
Router#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router(config)#line vty ?
  <0-15>  First Line number
Router(config)#line vty 0 15
Router(config-line)#password cisco
Router(config-line)#login
```

## 遠端登入

```bash
Router>en
Password:
Router1#telnet 192.168.80.254 # 或是192.168.80.249
Trying 192.168.80.254 ...Open


User Access Verification

Password:
Route2r>en
Password:
Router2#confi
Configuring from terminal, memory, or network [terminal]?
Enter configuration commands, one per line.  End with CNTL/Z.
Router(config)#
```
